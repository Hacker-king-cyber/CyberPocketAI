package com.cyberpocket.ai

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BluetoothSearching
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

private val Background = Color(0xFF071018)
private val Panel = Color(0xFF101F2B)
private val Cyan = Color(0xFF48E5D1)
private val TextMain = Color(0xFFEAF5F7)
private val TextMuted = Color(0xFF9DB1BC)

class MainActivity : ComponentActivity() {
    private var permissionGranted by mutableStateOf(false)

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results -> permissionGranted = results.values.any { it } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        permissionGranted = hasWifiPermissions()
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Cyan,
                    background = Background,
                    surface = Panel,
                    onBackground = TextMain,
                    onSurface = TextMain
                )
            ) {
                CyberPocketHome(
                    context = this,
                    onRequestPermissions = { requestNeededPermissions() },
                    permissionGranted = permissionGranted
                )
            }
        }
    }

    private fun hasWifiPermissions(): Boolean {
        val needed = if (Build.VERSION.SDK_INT >= 33) {
            Manifest.permission.NEARBY_WIFI_DEVICES
        } else {
            Manifest.permission.ACCESS_FINE_LOCATION
        }
        return ContextCompat.checkSelfPermission(this, needed) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestNeededPermissions() {
        val permissions = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) {
            permissions += Manifest.permission.NEARBY_WIFI_DEVICES
            permissions += Manifest.permission.BLUETOOTH_SCAN
            permissions += Manifest.permission.BLUETOOTH_CONNECT
        } else {
            permissions += Manifest.permission.ACCESS_FINE_LOCATION
            if (Build.VERSION.SDK_INT >= 31) {
                permissions += Manifest.permission.BLUETOOTH_SCAN
                permissions += Manifest.permission.BLUETOOTH_CONNECT
            } else {
                permissions += Manifest.permission.BLUETOOTH
                permissions += Manifest.permission.BLUETOOTH_ADMIN
            }
        }
        permissionLauncher.launch(permissions.distinct().toTypedArray())
    }
}

@Composable
private fun CyberPocketHome(
    context: Context,
    onRequestPermissions: () -> Unit,
    permissionGranted: Boolean
) {
    var selected by remember { mutableStateOf("Dashboard") }
    var wifiStatus by remember { mutableStateOf("Tap Wi-Fi Analyzer to view connection details.") }
    var scanStatus by remember { mutableStateOf("No scan running") }

    Surface(modifier = Modifier.fillMaxSize(), color = Background) {
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp),
            contentPadding = PaddingValues(top = 28.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text("CYBERPOCKET", color = Cyan, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                Text("AI SECURITY TOOLKIT", color = TextMain, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
                Text("Defensive tools for networks and devices you are authorized to test.", color = TextMuted, style = MaterialTheme.typography.bodyMedium)
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatusPill("LOCAL-FIRST")
                    StatusPill("ANDROID")
                }
            }
            item {
                ToolCard("Wi-Fi Analyzer", "View your current Wi-Fi connection information.", Icons.Default.Wifi, "Open analyzer") {
                    onRequestPermissions()
                    wifiStatus = getWifiInfo(context)
                    selected = "Wi-Fi Analyzer"
                }
            }
            item {
                ToolCard("BLE Scanner", "Permission-ready entry point for nearby Bluetooth LE discovery.", Icons.Default.BluetoothSearching, "Check permissions") {
                    onRequestPermissions()
                    scanStatus = if (permissionGranted) "Permissions may be available. BLE scan implementation can be added next." else "Requesting Bluetooth permissions. Enable Bluetooth in Android settings."
                    selected = "BLE Scanner"
                }
            }
            item {
                ToolCard("Authorized Network Discovery", "A safe placeholder for discovering devices on your own local network.", Icons.Default.NetworkCheck, "View status") {
                    scanStatus = "Network discovery is not running. Only scan networks you own or have permission to test."
                    selected = "Network Discovery"
                }
            }
            item {
                ToolCard("AI Security Advisor", "Practical defensive guidance and security checklists.", Icons.Default.Security, "Open advisor") {
                    scanStatus = "Quick checklist: update Android, use a screen lock, review app permissions, avoid unknown APKs, and secure your router."
                    selected = "AI Advisor"
                }
            }
            item {
                ToolCard("Reports", "Review the current local status and exportable-report placeholder.", Icons.Default.Description, "View report") {
                    scanStatus = "CyberPocket AI v1.0\\nSection: $selected\\nWi-Fi: $wifiStatus\\nStatus: $scanStatus"
                    selected = "Reports"
                }
            }
            item {
                Column(
                    modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(16.dp)
                ) {
                    Text("CURRENT PANEL: $selected", color = Cyan, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text(wifiStatus, color = TextMain)
                    Spacer(Modifier.height(8.dp))
                    Text(scanStatus, color = TextMuted)
                }
            }
            item {
                Text("Privacy note: this starter app does not upload scan data. Some Android Wi-Fi details require permissions and may be restricted by the device or OS.", color = TextMuted, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun StatusPill(label: String) {
    Text(
        label,
        color = Cyan,
        style = MaterialTheme.typography.labelSmall,
        modifier = Modifier.background(Color(0xFF12313A), RoundedCornerShape(50)).padding(horizontal = 12.dp, vertical = 7.dp)
    )
}

@Composable
private fun ToolCard(
    title: String,
    description: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    buttonText: String,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = Cyan, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(12.dp))
            Text(title, color = TextMain, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
        }
        Spacer(Modifier.height(8.dp))
        Text(description, color = TextMuted, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(12.dp))
        Button(onClick = onClick, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF174A52))) {
            Text(buttonText, color = TextMain)
        }
    }
}

private fun getWifiInfo(context: Context): String {
    return try {
        val manager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val info = manager.connectionInfo
        val ssid = info.ssid?.takeIf { it != "<unknown ssid>" } ?: "Hidden or unavailable"
        val rssi = info.rssi
        val speed = info.linkSpeed
        "SSID: $ssid\\nSignal: $rssi dBm\\nLink speed: $speed Mbps"
    } catch (e: Exception) {
        "Wi-Fi details unavailable. Check permissions and ensure Wi-Fi is enabled."
    }
}
