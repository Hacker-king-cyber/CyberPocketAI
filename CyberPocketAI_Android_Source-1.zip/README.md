# CyberPocket AI — Android starter project

This is a real native Android Studio project (Kotlin + Jetpack Compose), not a web-based phone mockup.

## Current features
- Native dashboard and dark cybersecurity UI
- Current Wi-Fi connection information where Android permissions/device restrictions allow
- Permission request scaffolding for Wi-Fi and Bluetooth
- Defensive security checklist
- UI placeholders for BLE scanning, authorized local-network discovery, and reports

## Important limitations
This starter is not yet a full penetration-testing toolkit. BLE scanning, network discovery, and report export are not implemented in this initial version. Wi-Fi scan results and some identifiers are restricted by Android version, device policy, and permissions. Only use future scanning features on devices/networks you own or are authorized to test.

## Build
Open this folder in Android Studio on a computer, allow Gradle sync, then choose:
Build > Build Bundle(s) / APK(s) > Build APK(s).

Application ID: `com.cyberpocket.ai`

This source ZIP is not itself an APK. It must be compiled by an Android build environment before it can be installed.
